export class user{
    name:string;
    age:number;
    score:number;
    id?:string;
}